<template>
  <div id="app">
    <CryptoApp />
  </div>
</template>

<script setup>
import CryptoApp from './components/CryptoApp.vue'
</script>

<style>
</style>