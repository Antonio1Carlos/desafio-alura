<template>
    <div class="engloba">
      <div class="ladoesquerdo">
        <img src="../assets/a.png" alt="a">
        <textarea v-model="inputText" placeholder="Digite o texto aqui..."></textarea>
        <p><img src="../assets/exclamação.png" alt="">Apenas letras minúsculas e sem acento.</p>      
        
        <div class="button">
          <button @click="convertText('encrypt')" class="button1">Criptografar</button>
          <button @click="convertText('decrypt')" class="button2">Descriptografar</button>
        </div>
      </div>
      
      <div class="ladodireito" v-if="!showRightSide">
        <img src="../assets/logo.svg" alt="logo">
        <h1>Nenhuma mensagem encontrada</h1>
        <p>Digite um texto que você deseja criptografar ou descriptografar.</p>
      </div>
  
      <div class="ladodireitopesquisado" v-if="showRightSide">
        <p>{{ outputText }}</p>
        <button @click="copyToClipboard" class="button2">Copiar</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        inputText: '',
        outputText: '',
        showRightSide: false
      }
    },
    methods: {
      encrypt(text) {
        return text
          .replace(/e/g, 'enter')
          .replace(/i/g, 'imes')
          .replace(/a/g, 'ai')
          .replace(/o/g, 'ober')
          .replace(/u/g, 'ufat');
      },
      decrypt(text) {
        return text
          .replace(/enter/g, 'e')
          .replace(/imes/g, 'i')
          .replace(/ai/g, 'a')
          .replace(/ober/g, 'o')
          .replace(/ufat/g, 'u');
      },
      convertText(mode) {
        if (this.inputText.trim()) {
          this.outputText = mode === 'encrypt'
            ? this.encrypt(this.inputText)
            : this.decrypt(this.inputText);
          this.showRightSide = true;
        }
      },
      copyToClipboard() {
        navigator.clipboard.writeText(this.outputText)
          .then(() => {
            alert('Texto copiado para a área de transferência!');
          })
          .catch(err => {
            alert('Erro ao copiar o texto: ' + err);
          });
      }
    }
  }
  </script>
  
  <style>
  * {
      padding: 0;
      margin: 0;
      box-sizing: border-box;
      font-family: Arial, Helvetica, sans-serif;
  }
  
  body {
      padding: 40px;
      overflow: hidden;
      background-color: hsl(156, 71%, 60%);
  }
  
  .engloba {
      display: flex;
      align-items: center;
      justify-content: space-between;
  }
  
  .ladoesquerdo {
      height: 90vh;
      display: flex;
      align-items: start;
      justify-content: start;
      flex-direction: column;
      textarea {
          margin-top: 168px;
          margin-left: 240px;
          margin-bottom: 440px;
          width: 680px;
          height: 200px; /* Ajuste a altura conforme necessário */
          border: none;
          background: transparent;
          font-size: 32px;
          color: #0A3871;
          resize: none; /* Desativa o redimensionamento */
      }
      textarea::placeholder {
          color: #0A3871;
          font-size: 32px;
      }
      textarea:focus {
          outline: none;
      }
      p {
          margin-left: 264px;
      }
      .button {
          margin-left: 264px;
          .button1 {
              background-color: #0A3871;
              color: hsl(156, 71%, 60%);
              margin-right: 24px;
              cursor: pointer;
          }
          .button2 {
              color: #0A3871;
              cursor: pointer;
          }
          button {
              width: 328px;
              height: 67px;
              border-radius: 24px;
              font-size: 16px;
              border: 1px solid #0A3871;
          }
      }
  }
  
  .ladodireito {
      width: 400px;
      height: 90vh;
      border-radius: 32px;
      background-color: hsl(156, 71%, 60%);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 32px;
      h1 {
          text-align: center;
          font-size: 24px;
      }
      p {
          text-align: center;
          font-size: 16px;
      }
  }
  
  .ladodireitopesquisado {
      display: none;
      width: 400px;
      height: 90vh;
      border-radius: 32px;
      background-color: #a1eecf;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-direction: column;
      padding: 32px;
      p {
          font-size: 20px;
          font-weight: 100;
          text-align: center;
          word-wrap: break-word;
      }
      button {
          width: 328px;
          height: 67px;
          border-radius: 24px;
          font-size: 16px;
          border: 1px solid #0A3871;
      }
  }
  </style>
  